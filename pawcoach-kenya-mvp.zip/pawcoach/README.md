# PawCoach Kenya

A minimal, data-light dog-training business app for one trainer/business owner.

## Included
- Node.js + Express backend
- SQLite local database (easy to move to PostgreSQL later)
- Minimal responsive multi-page SPA-style interface
- Clients and dogs
- Appointments and basic conflict checking
- M-Pesa Daraja STK Push + callback handling
- WhatsApp click-to-chat fallback and optional WhatsApp Cloud API endpoint
- Google Maps directions links for home visits
- Travel-aware scheduling foundation

## Run locally
1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Fill in M-Pesa credentials when ready.
4. Run:
   `npm install`
   `npm start`
5. Open `http://localhost:3000`.

## M-Pesa
For real payments you need a Safaricom Daraja app, shortcode, passkey, and a publicly reachable HTTPS callback URL. Start with sandbox, then switch `MPESA_ENV=production` after approval.

The callback endpoint is:
`POST /api/payments/mpesa/callback`

## WhatsApp
The app can open a lightweight WhatsApp click-to-chat link without an API integration. For automated business-initiated messages, configure WhatsApp Cloud API variables. Templates/consent requirements apply.

## Google Maps
The MVP opens Google Maps directions URLs, which keeps the app data-light. A future upgrade can use Google Routes API to calculate drive-time buffers automatically. Configure `GOOGLE_MAPS_API_KEY` when implementing server-side route calculations.

## Production next steps
- Add authentication/roles (owner/trainer/customer)
- HTTPS and secure secrets
- PostgreSQL for hosted production
- Background jobs for reminders
- WhatsApp templates and opt-in tracking
- Google Routes API travel-time matrix
- M-Pesa reconciliation/status polling and idempotency
- Audit logs, backups, rate limiting, CSRF protection where appropriate
