require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');
const Database = require('better-sqlite3');
const axios = require('axios');

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database(process.env.DB_FILE || './pawcoach.db');
db.pragma('journal_mode = WAL');

db.exec(`
CREATE TABLE IF NOT EXISTS clients (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT NOT NULL, email TEXT, address TEXT, lat REAL, lng REAL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS dogs (id INTEGER PRIMARY KEY AUTOINCREMENT, client_id INTEGER NOT NULL, name TEXT NOT NULL, breed TEXT, age TEXT, goals TEXT, notes TEXT, FOREIGN KEY(client_id) REFERENCES clients(id));
CREATE TABLE IF NOT EXISTS packages (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, description TEXT, price_kes INTEGER NOT NULL, sessions INTEGER DEFAULT 1, duration_min INTEGER DEFAULT 60, active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS appointments (id INTEGER PRIMARY KEY AUTOINCREMENT, client_id INTEGER NOT NULL, dog_id INTEGER NOT NULL, package_id INTEGER NOT NULL, starts_at TEXT NOT NULL, duration_min INTEGER NOT NULL, type TEXT DEFAULT 'home', address TEXT, lat REAL, lng REAL, status TEXT DEFAULT 'pending', payment_status TEXT DEFAULT 'unpaid', checkout_request_id TEXT, merchant_request_id TEXT, mpesa_receipt TEXT, notes TEXT, FOREIGN KEY(client_id) REFERENCES clients(id), FOREIGN KEY(dog_id) REFERENCES dogs(id), FOREIGN KEY(package_id) REFERENCES packages(id));
CREATE TABLE IF NOT EXISTS payments (id INTEGER PRIMARY KEY AUTOINCREMENT, appointment_id INTEGER, phone TEXT, amount INTEGER, status TEXT, merchant_request_id TEXT, checkout_request_id TEXT, receipt TEXT, raw TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(appointment_id) REFERENCES appointments(id));
`);

if (db.prepare('SELECT COUNT(*) c FROM packages').get().c === 0) {
  db.prepare('INSERT INTO packages (name,description,price_kes,sessions,duration_min) VALUES (?,?,?,?,?)').run('Puppy Starter','Foundation skills for young dogs',7500,4,60);
  db.prepare('INSERT INTO packages (name,description,price_kes,sessions,duration_min) VALUES (?,?,?,?,?)').run('Obedience Essentials','Practical obedience and loose-leash work',12000,6,60);
  db.prepare('INSERT INTO packages (name,description,price_kes,sessions,duration_min) VALUES (?,?,?,?,?)').run('Behaviour Consultation','One-to-one behaviour assessment',4500,1,90);
}

app.use(helmet({contentSecurityPolicy:false}));
app.use(morgan('tiny'));
app.use(express.json({limit:'1mb'}));
app.use(express.urlencoded({extended:true}));
app.use(express.static(path.join(__dirname,'public')));

function getClient(id){ return db.prepare('SELECT * FROM clients WHERE id=?').get(id); }
function getAppointment(id){ return db.prepare(`SELECT a.*, c.name client_name,c.phone client_phone,d.name dog_name,p.name package_name,p.price_kes FROM appointments a JOIN clients c ON c.id=a.client_id JOIN dogs d ON d.id=a.dog_id JOIN packages p ON p.id=a.package_id WHERE a.id=?`).get(id); }
function mapsUrl(address, lat, lng){
  if (lat && lng) return `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(lat+','+lng)}`;
  return `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(address || '')}`;
}

app.get('/api/dashboard',(req,res)=>{
  const today = new Date().toISOString().slice(0,10);
  const appointments = db.prepare(`SELECT a.*,c.name client_name,d.name dog_name,p.name package_name,p.price_kes FROM appointments a JOIN clients c ON c.id=a.client_id JOIN dogs d ON d.id=a.dog_id JOIN packages p ON p.id=a.package_id WHERE date(a.starts_at)=? ORDER BY a.starts_at`).all(today);
  const revenue = db.prepare("SELECT COALESCE(SUM(amount),0) total FROM payments WHERE status='success'").get().total;
  const clients = db.prepare('SELECT COUNT(*) c FROM clients').get().c;
  return res.json({appointments,revenue,clients});
});

app.get('/api/packages',(req,res)=>res.json(db.prepare('SELECT * FROM packages WHERE active=1 ORDER BY price_kes').all()));
app.get('/api/clients',(req,res)=>res.json(db.prepare('SELECT * FROM clients ORDER BY name').all()));
app.get('/api/clients/:id',(req,res)=>{
  const client=getClient(req.params.id); if(!client) return res.status(404).json({error:'Client not found'});
  client.dogs=db.prepare('SELECT * FROM dogs WHERE client_id=?').all(client.id);
  client.appointments=db.prepare(`SELECT a.*,d.name dog_name,p.name package_name,p.price_kes FROM appointments a JOIN dogs d ON d.id=a.dog_id JOIN packages p ON p.id=a.package_id WHERE a.client_id=? ORDER BY a.starts_at DESC`).all(client.id);
  res.json(client);
});

app.post('/api/clients',(req,res)=>{
  const {name,phone,email,address,lat,lng}=req.body; if(!name||!phone) return res.status(400).json({error:'Name and phone are required'});
  const info=db.prepare('INSERT INTO clients(name,phone,email,address,lat,lng) VALUES(?,?,?,?,?,?)').run(name,phone,email||null,address||null,lat||null,lng||null);
  res.json({id:info.lastInsertRowid});
});
app.post('/api/dogs',(req,res)=>{
  const {client_id,name,breed,age,goals,notes}=req.body; if(!client_id||!name) return res.status(400).json({error:'Client and dog name are required'});
  const info=db.prepare('INSERT INTO dogs(client_id,name,breed,age,goals,notes) VALUES(?,?,?,?,?,?)').run(client_id,name,breed||null,age||null,goals||null,notes||null); res.json({id:info.lastInsertRowid});
});

app.get('/api/appointments',(req,res)=>{
  const rows=db.prepare(`SELECT a.*,c.name client_name,c.phone client_phone,d.name dog_name,p.name package_name,p.price_kes FROM appointments a JOIN clients c ON c.id=a.client_id JOIN dogs d ON d.id=a.dog_id JOIN packages p ON p.id=a.package_id ORDER BY a.starts_at`).all();
  res.json(rows.map(r=>({...r,maps_url:mapsUrl(r.address,r.lat,r.lng)})));
});
app.post('/api/appointments',(req,res)=>{
  const {client_id,dog_id,package_id,starts_at,type='home',address,lat,lng,notes}=req.body;
  const pkg=db.prepare('SELECT * FROM packages WHERE id=? AND active=1').get(package_id); if(!pkg) return res.status(400).json({error:'Package not found'});
  if(!client_id||!dog_id||!starts_at) return res.status(400).json({error:'Client, dog and time are required'});
  const conflict=db.prepare(`SELECT id FROM appointments WHERE starts_at < datetime(?, '+' || duration_min || ' minutes') AND datetime(starts_at, '+' || duration_min || ' minutes') > ? AND status!='cancelled'`).get(starts_at,starts_at);
  if(conflict) return res.status(409).json({error:'Trainer schedule conflict'});
  const info=db.prepare('INSERT INTO appointments(client_id,dog_id,package_id,starts_at,duration_min,type,address,lat,lng,notes) VALUES(?,?,?,?,?,?,?,?,?,?)').run(client_id,dog_id,package_id,starts_at,pkg.duration_min,type,address||null,lat||null,lng||null,notes||null);
  res.json({id:info.lastInsertRowid, appointment:getAppointment(info.lastInsertRowid)});
});

function mpesaBase(){return process.env.MPESA_ENV==='production'?'https://api.safaricom.co.ke':'https://sandbox.safaricom.co.ke';}
async function mpesaToken(){
  if(!process.env.MPESA_CONSUMER_KEY||!process.env.MPESA_CONSUMER_SECRET) throw new Error('M-Pesa credentials are not configured');
  const auth=Buffer.from(`${process.env.MPESA_CONSUMER_KEY}:${process.env.MPESA_CONSUMER_SECRET}`).toString('base64');
  const r=await axios.get(mpesaBase()+'/oauth/v1/generate?grant_type=client_credentials',{headers:{Authorization:`Basic ${auth}`}}); return r.data.access_token;
}
function timestamp(){ const d=new Date(); const p=n=>String(n).padStart(2,'0'); return d.getFullYear()+p(d.getMonth()+1)+p(d.getDate())+p(d.getHours())+p(d.getMinutes())+p(d.getSeconds()); }
app.post('/api/payments/mpesa/stkpush',async(req,res)=>{
  try{
    const {appointment_id,phone}=req.body; const a=getAppointment(appointment_id); if(!a) return res.status(404).json({error:'Appointment not found'});
    if(!phone) return res.status(400).json({error:'M-Pesa phone number is required'});
    const token=await mpesaToken(); const ts=timestamp(); const password=Buffer.from(`${process.env.MPESA_SHORTCODE}${process.env.MPESA_PASSKEY}${ts}`).toString('base64');
    const r=await axios.post(mpesaBase()+'/mpesa/stkpush/v1/processrequest',{BusinessShortCode:process.env.MPESA_SHORTCODE,Password:password,Timestamp:ts,TransactionType:'CustomerPayBillOnline',Amount:a.price_kes,PartyA:phone,PartyB:process.env.MPESA_SHORTCODE,PhoneNumber:phone,CallBackURL:process.env.MPESA_CALLBACK_URL,AccountReference:process.env.MPESA_ACCOUNT_REFERENCE||'PawCoach',TransactionDesc:process.env.MPESA_TRANSACTION_DESC||'Dog training booking'},{headers:{Authorization:`Bearer ${token}`}});
    db.prepare('UPDATE appointments SET payment_status=?,checkout_request_id=?,merchant_request_id=? WHERE id=?').run('pending',r.data.CheckoutRequestID,r.data.MerchantRequestID,appointment_id);
    db.prepare('INSERT INTO payments(appointment_id,phone,amount,status,merchant_request_id,checkout_request_id,raw) VALUES(?,?,?,?,?,?,?)').run(appointment_id,phone,a.price_kes,'pending',r.data.MerchantRequestID,r.data.CheckoutRequestID,JSON.stringify(r.data));
    res.json({ok:true,message:r.data.CustomerMessage||'STK Push sent'});
  }catch(e){ console.error(e.response?.data||e.message); res.status(500).json({error:e.response?.data?.errorMessage||e.message}); }
});

app.post('/api/payments/mpesa/callback',(req,res)=>{
  const body=req.body?.Body?.stkCallback; if(!body) return res.json({ResultCode:0,ResultDesc:'Accepted'});
  const receipt=body.CallbackMetadata?.Item?.find(i=>i.Name==='MpesaReceiptNumber')?.Value;
  const amount=body.CallbackMetadata?.Item?.find(i=>i.Name==='Amount')?.Value;
  const phone=body.CallbackMetadata?.Item?.find(i=>i.Name==='PhoneNumber')?.Value;
  const payment=db.prepare('SELECT * FROM payments WHERE checkout_request_id=?').get(body.CheckoutRequestID);
  if(payment){ const success=body.ResultCode===0; db.prepare('UPDATE payments SET status=?,receipt=?,raw=? WHERE id=?').run(success?'success':'failed',receipt||null,JSON.stringify(body),payment.id); db.prepare('UPDATE appointments SET payment_status=?,mpesa_receipt=? WHERE id=?').run(success?'paid':'failed',receipt||null,payment.appointment_id); }
  res.json({ResultCode:0,ResultDesc:'Accepted'});
});

app.post('/api/whatsapp/send',async(req,res)=>{
  try{
    const {phone,message}=req.body; if(!phone||!message) return res.status(400).json({error:'Phone and message are required'});
    if(!process.env.WHATSAPP_ACCESS_TOKEN||!process.env.WHATSAPP_PHONE_NUMBER_ID) return res.status(501).json({error:'WhatsApp Cloud API is not configured. Use the click-to-chat fallback.'});
    const version=process.env.WHATSAPP_API_VERSION||'v23.0';
    const r=await axios.post(`https://graph.facebook.com/${version}/${process.env.WHATSAPP_PHONE_NUMBER_ID}/messages`,{messaging_product:'whatsapp',to:phone.replace(/\D/g,''),type:'text',text:{body:message}},{headers:{Authorization:`Bearer ${process.env.WHATSAPP_ACCESS_TOKEN}`}});
    res.json({ok:true,id:r.data.messages?.[0]?.id});
  }catch(e){res.status(500).json({error:e.response?.data?.error?.message||e.message});}
});

app.get('/api/maps/config',(req,res)=>res.json({enabled:Boolean(process.env.GOOGLE_MAPS_API_KEY),key:process.env.GOOGLE_MAPS_API_KEY||null}));

app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`PawCoach Kenya running at http://localhost:${PORT}`));
